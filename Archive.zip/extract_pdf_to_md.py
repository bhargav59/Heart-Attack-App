#!/usr/bin/env python3
"""
Extract content from the original PDF report
"""

import pdfplumber
from pathlib import Path

def extract_pdf_to_markdown(pdf_file, md_file):
    """Extract text from PDF and save as markdown"""
    
    print(f"📖 Extracting content from {pdf_file}...")
    
    all_text = []
    
    with pdfplumber.open(pdf_file) as pdf:
        print(f"   Total pages: {len(pdf.pages)}")
        
        for i, page in enumerate(pdf.pages, 1):
            print(f"   Processing page {i}/{len(pdf.pages)}...", end='\r')
            text = page.extract_text()
            if text:
                all_text.append(text)
        
        print(f"\n✅ Extracted {len(pdf.pages)} pages")
    
    # Combine all text
    full_text = "\n\n".join(all_text)
    
    # Save to markdown file
    with open(md_file, 'w', encoding='utf-8') as f:
        f.write(full_text)
    
    print(f"✅ Saved to {md_file}")
    print(f"📄 Total characters: {len(full_text):,}")
    
    return full_text

if __name__ == "__main__":
    pdf_file = "Final Report - Heart Attack Risk Prediction with Eval ML.pdf"
    md_file = "Original_Report_Extracted.md"
    
    extract_pdf_to_markdown(pdf_file, md_file)
