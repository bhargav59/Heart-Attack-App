#!/usr/bin/env python3
"""
Convert Markdown report to PDF using WeasyPrint
"""

import markdown2
from weasyprint import HTML, CSS
from pathlib import Path

def convert_md_to_pdf(md_file, pdf_file):
    """Convert markdown file to PDF with professional styling"""
    
    # Read markdown content
    with open(md_file, 'r', encoding='utf-8') as f:
        md_content = f.read()
    
    # Convert markdown to HTML
    html_content = markdown2.markdown(
        md_content,
        extras=[
            'tables',
            'fenced-code-blocks',
            'code-friendly',
            'header-ids',
            'toc',
            'break-on-newline'
        ]
    )
    
    # Create full HTML document with styling
    full_html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Heart Attack Risk Prediction - Final Report</title>
        <style>
            @page {{
                size: A4;
                margin: 2.5cm 2cm 2cm 2cm;
                @top-center {{
                    content: "Heart Attack Risk Prediction System";
                    font-size: 10pt;
                    color: #666;
                }}
                @bottom-right {{
                    content: "Page " counter(page) " of " counter(pages);
                    font-size: 10pt;
                    color: #666;
                }}
            }}
            
            body {{
                font-family: 'Georgia', 'Times New Roman', serif;
                font-size: 11pt;
                line-height: 1.6;
                color: #333;
                max-width: 100%;
            }}
            
            h1 {{
                color: #2c3e50;
                font-size: 24pt;
                font-weight: bold;
                margin-top: 24pt;
                margin-bottom: 12pt;
                page-break-after: avoid;
                border-bottom: 2px solid #667eea;
                padding-bottom: 8pt;
            }}
            
            h2 {{
                color: #34495e;
                font-size: 18pt;
                font-weight: bold;
                margin-top: 20pt;
                margin-bottom: 10pt;
                page-break-after: avoid;
                border-bottom: 1px solid #ddd;
                padding-bottom: 4pt;
            }}
            
            h3 {{
                color: #555;
                font-size: 14pt;
                font-weight: bold;
                margin-top: 16pt;
                margin-bottom: 8pt;
                page-break-after: avoid;
            }}
            
            h4 {{
                color: #666;
                font-size: 12pt;
                font-weight: bold;
                margin-top: 12pt;
                margin-bottom: 6pt;
            }}
            
            p {{
                margin-bottom: 10pt;
                text-align: justify;
            }}
            
            table {{
                width: 100%;
                border-collapse: collapse;
                margin: 16pt 0;
                font-size: 10pt;
                page-break-inside: auto;
            }}
            
            table thead {{
                background-color: #667eea;
                color: white;
            }}
            
            table th {{
                padding: 8pt;
                text-align: left;
                font-weight: bold;
                border: 1px solid #ddd;
            }}
            
            table td {{
                padding: 6pt 8pt;
                border: 1px solid #ddd;
            }}
            
            table tbody tr:nth-child(even) {{
                background-color: #f8f9fa;
            }}
            
            table tr {{
                page-break-inside: avoid;
            }}
            
            code {{
                font-family: 'Courier New', monospace;
                font-size: 9pt;
                background-color: #f5f5f5;
                padding: 2pt 4pt;
                border-radius: 3pt;
                color: #c7254e;
            }}
            
            pre {{
                background-color: #f8f8f8;
                border: 1px solid #ddd;
                border-left: 4px solid #667eea;
                padding: 12pt;
                margin: 12pt 0;
                overflow-x: auto;
                font-family: 'Courier New', monospace;
                font-size: 9pt;
                line-height: 1.4;
                page-break-inside: avoid;
            }}
            
            pre code {{
                background-color: transparent;
                padding: 0;
                color: #333;
            }}
            
            ul, ol {{
                margin: 10pt 0 10pt 20pt;
                padding-left: 20pt;
            }}
            
            li {{
                margin-bottom: 6pt;
            }}
            
            blockquote {{
                margin: 16pt 0;
                padding: 12pt 16pt;
                background-color: #f9f9f9;
                border-left: 4px solid #667eea;
                font-style: italic;
                color: #555;
                page-break-inside: avoid;
            }}
            
            hr {{
                border: none;
                border-top: 2px solid #ddd;
                margin: 20pt 0;
            }}
            
            a {{
                color: #667eea;
                text-decoration: none;
            }}
            
            .page-break {{
                page-break-before: always;
            }}
            
            /* Ensure headers stay with content */
            h1, h2, h3, h4, h5, h6 {{
                page-break-after: avoid;
            }}
            
            /* Keep lists together */
            ul, ol {{
                page-break-inside: avoid;
            }}
            
            /* Performance metrics highlighting */
            strong {{
                color: #2c3e50;
                font-weight: bold;
            }}
            
            /* Status badges */
            .status {{
                display: inline-block;
                padding: 4pt 8pt;
                border-radius: 4pt;
                font-size: 9pt;
                font-weight: bold;
            }}
        </style>
    </head>
    <body>
        {html_content}
    </body>
    </html>
    """
    
    # Convert HTML to PDF
    print(f"Converting {md_file} to PDF...")
    HTML(string=full_html).write_pdf(pdf_file)
    print(f"✅ PDF created successfully: {pdf_file}")
    print(f"📄 File size: {Path(pdf_file).stat().st_size / 1024:.2f} KB")

if __name__ == "__main__":
    md_file = "Final_Report_Heart_Attack_Prediction.md"
    pdf_file = "Final_Report_Heart_Attack_Prediction.pdf"
    
    convert_md_to_pdf(md_file, pdf_file)
